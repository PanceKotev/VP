﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanLab8
{
    public class Pacman
    {
        public enum DIRECTION
        {
            LEFT,
            RIGHT,
            UP,
            DOWN
        }
        public int X { get; set; }
        public int Y { get; set; }
        public static int radius { get; set; }
        public int Speed { get; set; }
        public bool isOpen { get; set; }
        public Brush brush { get; set; }
        public DIRECTION facing { get; set; }
        public Pacman()
        {
            radius = 20;
            Speed = radius;
            brush = new SolidBrush(Color.Yellow);
            X = 280;
            Y = 200;
            facing = DIRECTION.RIGHT;
            isOpen = false;
        }
        public void ChangeDirection(DIRECTION direction)
        {
            facing = direction;
        }
        public void Move(int width, int height)
        {
            if (facing == DIRECTION.RIGHT)
            {
                X+=40;
                if (X >= 600)
                    X = 0;
            }
            else if (facing == DIRECTION.LEFT)
            {
                X-=40;
                if (X < 0)
                    X = 560;
            }
            else if (facing == DIRECTION.UP)
            {
                Y-=40;
                if (Y < 0)
                    Y = 360;
            }
            else if (facing == DIRECTION.DOWN)
            {
                Y += 40;
                if (Y >= 400)
                    Y = 0;
            }
            isOpen = !isOpen;

        }
        public void Draw(Graphics g)
        {
            if (!isOpen)
            {
                g.FillEllipse(brush, X, Y,2*radius,2*radius);
            }
            else
            {
                if (facing == DIRECTION.RIGHT)
                {
                    g.FillPie(brush, X, Y, 2*radius, 2*radius, 30, 300);
                }
                else if (facing == DIRECTION.LEFT)
                {
                    g.FillPie(brush, X, Y, radius * 2, radius * 2, 210, 300);
                }
                else if (facing == DIRECTION.UP)
                {
                    g.FillPie(brush, X, Y, radius * 2, radius * 2, 300, 300);
                }
                else if (facing == DIRECTION.DOWN)
                {
                    g.FillPie(brush, X, Y, radius * 2, radius * 2, 120, 300);
                }


            }
        }


    }
}
